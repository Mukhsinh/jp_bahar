1:"$Sreact.fragment"
2:I[61398,["5730","static/chunks/44530001-a26648c04669f22e.js","4240","static/chunks/4240-3fd4069132ab070c.js","8720","static/chunks/8720-46160b5e277eeb9e.js","7177","static/chunks/app/layout-b974186d5cea5608.js"],"AuthErrorHandler"]
3:I[52961,["5730","static/chunks/44530001-a26648c04669f22e.js","4240","static/chunks/4240-3fd4069132ab070c.js","8720","static/chunks/8720-46160b5e277eeb9e.js","7177","static/chunks/app/layout-b974186d5cea5608.js"],"SettingsProvider"]
4:I[9766,[],""]
5:I[49567,["5707","static/chunks/5707-db311c8fa00aafb3.js","8039","static/chunks/app/error-bc55f88d9d913f5c.js"],"default"]
6:I[98924,[],""]
7:I[52619,["2619","static/chunks/2619-04bc32f026a0d946.js","4345","static/chunks/app/not-found-61e2ff7719a67b6c.js"],""]
8:I[18720,["5730","static/chunks/44530001-a26648c04669f22e.js","4240","static/chunks/4240-3fd4069132ab070c.js","8720","static/chunks/8720-46160b5e277eeb9e.js","7177","static/chunks/app/layout-b974186d5cea5608.js"],"Toaster"]
9:I[81959,[],"ClientPageRoot"]
a:I[28481,["5707","static/chunks/5707-db311c8fa00aafb3.js","200","static/chunks/app/forbidden/page-45388735a6765420.js"],"default"]
d:I[24431,[],"OutletBoundary"]
f:I[15278,[],"AsyncMetadataOutlet"]
11:I[24431,[],"ViewportBoundary"]
13:I[24431,[],"MetadataBoundary"]
14:"$Sreact.suspense"
16:I[57150,[],""]
:HL["/_next/static/css/89e3b23ca00b38ed.css","style"]
0:{"P":null,"b":"YT7rR2RKdxudjCvN56c4O","p":"","c":["","forbidden"],"i":false,"f":[[["",{"children":["forbidden",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/89e3b23ca00b38ed.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"id","data-scroll-behavior":"smooth","suppressHydrationWarning":true,"children":["$","body",null,{"className":"__variable_a80a2d font-sans antialiased","suppressHydrationWarning":true,"children":[["$","$L2",null,{}],["$","$L3",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","error":"$5","errorStyles":[],"errorScripts":[],"template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"flex min-h-screen flex-col items-center justify-center bg-gray-50","children":["$","div",null,{"className":"text-center","children":[["$","h1",null,{"className":"text-6xl font-bold text-gray-900","children":"404"}],["$","h2",null,{"className":"mt-4 text-2xl font-semibold text-gray-700","children":"Halaman Tidak Ditemukan"}],["$","p",null,{"className":"mt-2 text-gray-600","children":"Maaf, halaman yang Anda cari tidak dapat ditemukan."}],["$","div",null,{"className":"mt-6","children":["$","$L7",null,{"href":"/","children":["$","button",null,{"className":"inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2","ref":"$undefined","children":"Kembali ke Beranda"}]}]}]]}]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","$L8",null,{"position":"top-right","richColors":true}]]}]}]]}],{"children":["forbidden",["$","$1","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$L9",null,{"Component":"$a","searchParams":{},"params":{},"promises":["$@b","$@c"]}],null,["$","$Ld",null,{"children":["$Le",["$","$Lf",null,{"promise":"$@10"}]]}]]}],{},null,false]},null,false]},[["$","div","l",{"className":"flex items-center justify-center min-h-screen","children":["$","div",null,{"className":"animate-spin rounded-full border-2 border-gray-300 border-t-blue-600 h-8 w-8"}]}],[],[]],false],["$","$1","h",{"children":[null,[["$","$L11",null,{"children":"$L12"}],null],["$","$L13",null,{"children":["$","div",null,{"hidden":true,"children":["$","$14",null,{"fallback":null,"children":"$L15"}]}]}]]}],false]],"m":"$undefined","G":["$16",[]],"s":false,"S":true}
b:{}
c:"$0:f:0:1:2:children:2:children:1:props:children:0:props:params"
12:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
e:null
17:I[80622,[],"IconMark"]
10:{"metadata":[["$","title","0",{"children":"JASPEL - Enterprise Incentive & KPI System"}],["$","meta","1",{"name":"description","content":"Sistem Manajemen Insentif dan KPI Berbasis P1, P2, P3"}],["$","link","2",{"rel":"icon","href":"/favicon.svg"}],["$","$L17","3",{}]],"error":null,"digest":"$undefined"}
15:"$10:metadata"
